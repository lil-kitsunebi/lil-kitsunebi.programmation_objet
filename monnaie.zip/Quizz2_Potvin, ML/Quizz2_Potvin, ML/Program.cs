﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace Quizz2_Potvin__ML
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an amount in cents :");
            int numberCents = int.Parse(Console.ReadLine());

            int nbRestant = numberCents;
            int dollars = 0;
            int quarters = 0;
            int dimes = 0;
            int nickels = 0;
            int pennies = 0;

            dollars = nbRestant/ 100;
            nbRestant -= dollars*100;
            quarters = nbRestant / 25;
            nbRestant -= quarters*25;
            dimes = nbRestant / 10;
            nbRestant -= dimes*10;
            nickels = nbRestant / 5;
            nbRestant -= nickels*5;
            pennies = nbRestant;

            Console.WriteLine("\nYou can provide this change as follow:\n" + "dollars: " + dollars + "\nquarters: " + quarters + "\ndimes: " + dimes + "\nnickels: " + nickels + "\npennies: " + pennies);
            Console.WriteLine("\n-------------------------------------------\n" + "Part 2 - Solution using the modulo operator\n" + "-------------------------------------------\n");

            nbRestant = numberCents;

            if (nbRestant > 0)
            {
                if (nbRestant % 100 == 0)
                {
                    dollars = nbRestant / 100;
                    nbRestant -= dollars * 100;
                }
                else
                {
                    dollars = nbRestant / 100;
                    nbRestant -= dollars * 100;
                }
                
            }

            if (nbRestant > 0)
            {
                if (nbRestant % 25 == 0)
                {
                    quarters = nbRestant / 25;
                    nbRestant -= quarters * 25;
                }
                else
                {
                    quarters = nbRestant / 25;
                    nbRestant -= quarters * 25;
                }
            }

            if (nbRestant > 0)
            {
                if (nbRestant % 10 == 0)
                {
                    dimes = nbRestant / 10;
                    nbRestant -= dimes * 10;
                }
                else
                {
                    dimes = nbRestant / 10;
                    nbRestant -= dimes * 10;
                }
            }

            if (nbRestant > 0)
            {
                if (nbRestant % 5 == 0)
                {
                    nickels = nbRestant / 5;
                    nbRestant -= nickels * 5;
                }
                else
                {
                    nickels = nbRestant / 5;
                    nbRestant -= nickels * 5;
                }
            }
            pennies = nbRestant;

            Console.WriteLine("You can provide this change as follow:\n" + "dollars: " + dollars + "\nquarters: " + quarters + "\ndimes: " + dimes + "\nnickels: " + nickels + "\npennies: " + pennies);
        }
    }
}
