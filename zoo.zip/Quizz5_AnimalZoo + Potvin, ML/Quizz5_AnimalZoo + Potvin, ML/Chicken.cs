﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Chicken
    {
        public Bird chicken;
        public Chicken(Bird chicken)
        { this.chicken = chicken; }
    }
}
