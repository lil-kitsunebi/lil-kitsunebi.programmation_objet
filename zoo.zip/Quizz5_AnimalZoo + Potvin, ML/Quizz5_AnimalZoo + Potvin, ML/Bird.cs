﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Bird
    {
        public Animal bird;
        public Bird(Animal bird)
        { this.bird = bird; }

        public void Speak()
        {
            Console.WriteLine("The bird age is " + bird.age);
            Console.WriteLine("The bird weight is " + bird.weight);
            Console.WriteLine("The bird gender is " + bird.gender);
        }
    }
}
