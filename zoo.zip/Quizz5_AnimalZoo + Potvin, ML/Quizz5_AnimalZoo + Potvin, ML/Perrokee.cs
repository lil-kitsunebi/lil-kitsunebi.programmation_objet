﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Perrokee
    {
        public Bird perrokee;
        public IFlyable flyer = new Flyer();
        public ISingable singer = new Singer();

        public Perrokee(Bird perrokee)
        { this.perrokee = perrokee; }

        //public void Fly()
        //{ Console.WriteLine("The perrokee is flying while talking..."); }
        //public void Sing()
        //{ Console.WriteLine("The perrokee singing japanese..."); }
    }
}
