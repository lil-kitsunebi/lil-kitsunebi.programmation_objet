﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Eagle
    {
        public Bird eagle;
        public IFlyable flyer = new Flyer();

        public Eagle(Bird eagle)
        { this.eagle = eagle; }
    }
}
