﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Animal
    {
        public int age { get; set; }
        public int weight { get; set; }
        public string gender { get; set; }

        public Animal(int age, int weight, string gender)
        {
            this.age = age;
            this.weight = weight;
            this.gender = gender;
        }

        public void Eat()
        {
            Console.WriteLine("The animal is eating...");
        }
        public void Sleep()
        {
            Console.WriteLine("The animal is sleeping...");
        }

        public virtual void Speak()
        {
            Console.WriteLine("The animal age is " + age);
            Console.WriteLine("The animal weight is " + weight);
            Console.WriteLine("The animal gender is " + gender);
        }
    }
}
