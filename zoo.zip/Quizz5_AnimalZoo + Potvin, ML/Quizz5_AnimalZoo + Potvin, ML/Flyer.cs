﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Flyer: IFlyable
    {
        public void Fly()
        { Console.WriteLine("Flying smoothly..."); }
    }
}
