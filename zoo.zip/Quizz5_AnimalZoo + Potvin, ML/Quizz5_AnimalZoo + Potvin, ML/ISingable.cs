﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    interface ISingable
    { void Sing(); }
}
