﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Sparrow
    {
        public Bird sparrow;
        public IFlyable flyer = new Flyer();
        public ISingable singer = new Singer();

        public Sparrow(Bird sparrow)
        { this.sparrow = sparrow; }

        public void Sing()
        { Console.WriteLine("I am inside Sparrow class and I am singing!"); }
    }
}
