﻿using System;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Zoo
    {
        static void Main(string[] args)
        {
            Animal a = new Animal(2, 2, "male");
            a.Speak();
            a.Sleep();

            Console.WriteLine("\n------------------------------------------\n");
            
            Fish f = new Fish(1, 1, "male");
            f.Speak();

            Console.WriteLine("\n------------------------------------------\n");

            Animal a1 = new Animal(4, 2, "female");
            Bird b = new Bird(a1);
            a1.Speak();
            a1.Sleep();
            b.Speak();

            Console.WriteLine("\n------------------------------------------\n");

            Animal a2 = new Animal(2, 1, "female");
            Bird b1 = new Bird(a2);
            Sparrow s = new Sparrow(b1);
            a2.Speak();
            a2.Sleep();
            b1.Speak();
            
            s.Sing();
            s.singer.Sing();
            s.flyer.Fly();

            Console.WriteLine("\n------------------------------------------\n");

            Animal a3 = new Animal(5, 3, "male");
            Bird b2 = new Bird(a3);
            Perrokee p = new Perrokee(b2);
            a3.Speak();
            a3.Sleep();
            b2.Speak();
            
            p.singer.Sing();
            p.flyer.Fly();

            Console.WriteLine("\n------------------------------------------\n");

            Animal a4 = new Animal(4, 5, "male");
            Bird b3 = new Bird(a4);
            Eagle e = new Eagle(b3);
            a4.Speak();
            a4.Sleep();
            b3.Speak();
            
            e.flyer.Fly();

            Console.WriteLine("\n------------------------------------------\n");

            Animal a5 = new Animal(2, 3, "female");
            Bird b4 = new Bird(a5);
            Chicken c = new Chicken(b4);
            a5.Speak();
            a5.Sleep();
            b4.Speak();
        }
    }
}
