﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Singer: ISingable
    {
        public void Sing()
        { Console.WriteLine("Singing nice..."); }
    }
}
