﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quizz5_AnimalZoo___Potvin__ML
{
    class Fish
    {
        public Animal fish;
        public Fish(int age, int weight, string gender)
        { this.fish = new Animal(age, weight, gender); }

        public void Speak()
        {
            Console.WriteLine("The fish age is " + fish.age);
            Console.WriteLine("The fish weight is " + fish.weight);
            Console.WriteLine("The fish gender is " + fish.gender);
        }
    }
}
