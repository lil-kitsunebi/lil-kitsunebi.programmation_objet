﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pw2Bank___Potvin__ML
{
    class accountComparer
    {
    }
}
