﻿using System;
using System.Collections;

namespace pw2Bank___Potvin__ML
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What do you want to do?\n1- Add a bank account\n2- Remove a bank account\n3- Display the information of a particuliar client's account\n" +
                    "4- Apply a deposit to a particular account\n5- Apply a withdrawal from a particular account\n6- Sort and display the list of clients\n" +
                    "7- Display the average balance value of the accounts\n8- Display the total balance value of the accounts\n9- Exit the application");
            int choix = int.Parse(Console.ReadLine());



            //dara has added these lines
            bankAccount[] account = new bankAccount[100];

            for (int i = 0; i < account.Length; i++)
            {
                account[i] = new bankAccount();

            }
            var order = 0;

            //end of dara modif.



            while (choix != 9)
            {
                // bankAccount[] account = new bankAccount[100]; //dara: put this out of the loop
                var generator = new Random();
                int wichAccount = 0;
                // var order = 0; //dara: put this out of the loop
                string nameClient = "";
                var nbRandom = 0;
                float money = 0f;

                if (choix == 1) //add bank account
                { 
                    nbRandom = generator.Next(10000, 10099);
                    Console.Write("\nEnter your name: ");
                    nameClient = Console.ReadLine();
                    Console.Write("Enter the balance for your bank account: ");
                    money = float.Parse(Console.ReadLine());
                    account[order] = makeBankAccount(nameClient, nbRandom, money, 1);
                    account[order].display();
                    order += 1;
                }
               
                if (choix == 2) //remove bank account
                {
                    Console.Write("\nEnter the # of the bank account you want to remove: ");
                    wichAccount = int.Parse(Console.ReadLine());
                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber == wichAccount)
                        {
                            allAccount.name = "";
                            allAccount.accountNumber = 0;
                            allAccount.balance = 0f;
                            allAccount.howManyA = 0;
                            Console.WriteLine("Bank account removed.\n");
                        }
                    }
                }

                if (choix == 3) //display info of a particuliar account
                {
                    Console.Write("\nEnter the # of the bank account you want to see: ");
                    wichAccount = int.Parse(Console.ReadLine());
                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber == wichAccount)
                        {
                            allAccount.display();
                        }
                    }
                }

                if (choix == 4) //deposit
                {
                    Console.Write("\nEnter the # of the bank account you want to apply a deposit: ");
                    wichAccount = int.Parse(Console.ReadLine());
                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber == wichAccount)
                        {
                            Console.Write("Enter the amount for the deposit: ");
                            float deposit = float.Parse(Console.ReadLine());
                            allAccount.balance += deposit;
                            Console.WriteLine("The balance is now: " + allAccount.balance + "$\n");
                        }
                    }
                }
                
                if (choix == 5) //withdrawal
                {
                    Console.Write("\nEnter the # of the bank account you want to apply a withdrawal: ");
                    wichAccount = int.Parse(Console.ReadLine());
                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber == wichAccount)
                        {
                            Console.Write("Enter the amount for the withdrawal: ");
                            float withdrawal = float.Parse(Console.ReadLine());
                            if (withdrawal > allAccount.balance)
                            {
                                Console.WriteLine("Error. You don't have enough money for this withdrawal.\n");
                            }
                            else
                            {
                                allAccount.balance -= withdrawal;
                                Console.WriteLine("The balance is now: " + allAccount.balance + "$\n");
                            }
                        }
                    }
                }

                if (choix == 6) //sort and display accounts
                {
                    string tempName = "";
                    int tempAccount = 0;
                    float tempBalance = 0f;
                    int tempHow = 0;

                    //Array.Sort(account, new accountComparer());
                    for (int i = 0; i <= account.Length - 1; i++)
                    {
                        for (int j = i + 1; j < account.Length; j++)
                        {
                            if (account[i].accountNumber > account[j].accountNumber)
                            {
                                tempName = account[i].name;
                                tempAccount = account[i].accountNumber;
                                tempBalance = account[i].balance;
                                tempHow = account[i].howManyA;

                                account[i].name = account[j].name;
                                account[i].accountNumber = account[j].accountNumber;
                                account[i].balance = account[j].balance;
                                account[i].howManyA = account[j].howManyA;

                                account[j].name = tempName;
                                account[j].accountNumber = tempAccount;
                                account[j].balance = tempBalance;
                                account[j].howManyA = tempHow;
                            }
                        }
                    }

                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber != 0)
                        {
                            allAccount.display();
                        }
                    }
                }

                if (choix == 7) //display average
                {
                    float sumAverage = 0f;
                    int div = 0;
                    float average = 0f;

                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber != 0)
                        {
                            div += allAccount.howManyA;
                            sumAverage += allAccount.balance;
                        }
                    }
                    average = sumAverage / div;
                    Console.WriteLine("\nThe average balance is: " + average + "$\n");
                }

                if (choix == 8) //display total
                {
                    float sumTotal = 0f;

                    foreach (bankAccount allAccount in account)
                    {
                        if (allAccount.accountNumber != 0)
                        {
                            sumTotal += allAccount.balance;
                        }
                    }
                    Console.WriteLine("\nThe total balance is: " + sumTotal + "$\n");
                }
                
                Console.WriteLine("What do you want to do?\n1- Add a bank account\n2- Remove a bank account\n3- Display the information of a particuliar client's account\n" +
                    "4- Apply a deposit to a particular account\n5- Apply a withdrawal from a particular account\n6- Sort and display the list of clients\n" +
                    "7- Display the average balance value of the accounts\n8- Display the total balance value of the accounts\n9- Exit the application");
                choix = int.Parse(Console.ReadLine());
            }
        }

        //class accountComparer : IComparer
        //{
        //    public int Compare(object x, object y)
        //    {
        //        return (new CaseInsensitiveComparer()).Compare(((bankAccount)x).accountNumber, ((bankAccount)y).accountNumber);
        //
        //    }
        //}

        static bankAccount makeBankAccount(string _name, int _accountNumber, float _balance, int _howManyA)
        {
            bankAccount toReturn = new bankAccount();
            toReturn.Name = _name;
            toReturn.AccountNumber = _accountNumber;
            toReturn.Balance = _balance;
            toReturn.HowManyA = _howManyA;

            return toReturn;
        }
    }
}
