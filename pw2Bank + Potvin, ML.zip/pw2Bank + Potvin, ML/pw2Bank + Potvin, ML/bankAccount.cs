﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pw2Bank___Potvin__ML
{
    class bankAccount
    {
        public string name = "";
        public int accountNumber = 0;
        public float balance = 0f;
        public int howManyA = 0;

        public void display()
        {
            Console.WriteLine(accountNumber + ": " + name + " has " + balance + "$\n");
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int AccountNumber
        { 
            get { return accountNumber; }
            set { accountNumber = value; }
        }
        public float Balance
        {
            get { return balance; }
            set 
            {
                if (value <= 0)
                { balance = 0f; }
                else
                { balance = value; }
            }
        }
        public int HowManyA
        {
            get { return howManyA; }
            set { howManyA = value; }
        }
    }
}
