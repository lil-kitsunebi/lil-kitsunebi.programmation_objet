﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shamim___Potvin__ML
{
    class healthy : burger
    {
        public healthy(string _name, string _roll, string _meat, float _price) : base(_name, _roll, _meat, _price)
        { }

        public void addEgg()
        {
            Console.WriteLine("Added Egg for an extra 5,43$");
            Price += 5.43f;
        }

        public void addLentils()
        {
            Console.WriteLine("Added Lentils for an extra 3,41$");
            Price += 3.41f;
        }
    }
}
