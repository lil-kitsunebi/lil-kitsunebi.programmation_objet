﻿using System;

namespace Shamim___Potvin__ML
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Shamim's Burgers! What kind of hamburger do you want?\n1- Basic hamburger (up to 4 additional additions)" +
                "\n2- Healthy hamburger (up to 2 additional additions)\n3- Deluxe hamburger (comes with chips and a drink as additions, but no extra additions are allowed)\n4- Exit");
            int choice = int.Parse(Console.ReadLine());

            while (choice != 4)
            {
                int tomato = 0;
                int lettuce = 0;
                int cheese = 0;
                int carrot = 0;
                int egg = 0;
                int lentils = 0;
                
                if (choice == 1)
                {
                    burger newBurger1 = new burger("Basic", "White", "Sausage", 3.56f);

                    Console.WriteLine("\nDo you want to add anything to your basic hamburger? Yes or no");
                    string addAnything = Console.ReadLine();

                    if (addAnything.ToLower() == "yes")
                    {
                        newBurger1.Display();

                        Console.WriteLine("\nWhat do you want to add? (up to 4 items):\n1- Tomato (0,27$)\n2- Lettuce (0,75$)\n3- Cheese (1,13$)\n4- Carrot (0,50$)\n5- Nothing");
                        int addToBurger = int.Parse(Console.ReadLine());

                        while (addToBurger != 5)
                        {
                            if (addToBurger == 1)
                            {
                                if (tomato == 0)
                                {
                                    tomato += 1;
                                    newBurger1.addTomato();
                                }

                                else
                                {
                                    Console.WriteLine("Item already added.");
                                }
                            }

                            if (addToBurger == 2)
                            {
                                if (lettuce == 0)
                                {
                                    lettuce += 1;
                                    newBurger1.addLettuce();
                                }

                                else
                                {
                                    Console.WriteLine("Item already added.");
                                }
                            }

                            if (addToBurger == 3)
                            {
                                if (cheese == 0)
                                {
                                    cheese += 1;
                                    newBurger1.addCheese();
                                }

                                else
                                {
                                    Console.WriteLine("Item already added.");
                                }
                            }

                            if (addToBurger == 4)
                            {
                                if (carrot == 0)
                                {
                                    carrot += 1;
                                    newBurger1.addCarrot();
                                }

                                else
                                {
                                    Console.WriteLine("Item already added.");
                                }
                            }

                            Console.WriteLine("\nWhat do you want to add? (up to 4 items):\n1- Tomato (0,27$)\n2- Lettuce (0,75$)\n3- Cheese (1,13$)\n4- Carrot (0,50$)\n5- Nothing");
                            addToBurger = int.Parse(Console.ReadLine());

                        }
                        newBurger1.total();
                    }

                    else
                    {
                        newBurger1.Display();
                    }
                }

                if (choice == 2)
                {
                    healthy newBurger2 = new healthy("Healthy", "Brown rye", "Bacon", 5.67f);

                    Console.WriteLine("\nDo you want to add anything to your basic hamburger? Yes or no");
                    string addAnything = Console.ReadLine();

                    if (addAnything.ToLower() == "yes")
                    {
                        int only2 = 0;
                        newBurger2.Display();

                        Console.WriteLine("\nWhat do you want to add? (up to 2 items):\n1- Tomato (0,27$)\n2- Lettuce (0,75$)\n3- Cheese (1,13$)" +
                            "\n4- Carrot (0,50$)\n5- Egg (5,43$)\n6- Lentils (3,41$)\n7- Nothing");
                        int addToBurger = int.Parse(Console.ReadLine());

                        while (addToBurger != 7)
                        {
                            if (addToBurger == 1)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (tomato == 0)
                                    {
                                        tomato += 1;
                                        newBurger2.addTomato();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            if (addToBurger == 2)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (lettuce == 0)
                                    {
                                        lettuce += 1;
                                        newBurger2.addLettuce();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            if (addToBurger == 3)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (cheese == 0)
                                    {
                                        cheese += 1;
                                        newBurger2.addCheese();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            if (addToBurger == 4)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (carrot == 0)
                                    {
                                        carrot += 1;
                                        newBurger2.addCarrot();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            if (addToBurger == 5)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (egg == 0)
                                    {
                                        egg += 1;
                                        newBurger2.addEgg();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            if (addToBurger == 6)
                            {
                                if (only2 == 2)
                                {
                                    Console.WriteLine("You can't add more items.");
                                }

                                else
                                {
                                    if (lentils == 0)
                                    {
                                        lentils += 1;
                                        newBurger2.addLentils();
                                        only2 += 1;
                                    }

                                    else
                                    {
                                        Console.WriteLine("Item already added.");
                                    }
                                }
                            }

                            Console.WriteLine("\nWhat do you want to add? (up to 2 items):\n1- Tomato (0,27$)\n2- Lettuce (0,75$)\n3- Cheese (1,13$)" +
                            "\n4- Carrot (0,50$)\n5- Egg (5,43$)\n6- Lentils (3,41$)\n7- Nothing");
                            addToBurger = int.Parse(Console.ReadLine());

                        }
                        newBurger2.total();
                    }

                    else
                    {
                        newBurger2.Display();
                    }
                }

                if (choice == 3)
                {
                    deluxe newBurger3 = new deluxe("Deluxe", "White", "Sausage & Bacon", 14.54f);
                    newBurger3.Display();
                    newBurger3.addChips();
                    newBurger3.addDrink();
                    newBurger3.total();
                }

                Console.WriteLine("\nWelcome to Shamim's Burgers! What kind of hamburger do you want?\n1- Basic hamburger (up to 4 additional additions)" +
                "\n2- Healthy hamburger (up to 2 additional additions)\n3- Deluxe hamburger (comes with chips and a drink as additions, but no extra additions are allowed)\n4- Exit");
                choice = int.Parse(Console.ReadLine());
            }
        }
    }
}
