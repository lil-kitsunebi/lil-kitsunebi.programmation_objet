﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shamim___Potvin__ML
{
    class deluxe : burger
    {
        public deluxe(string _name, string _roll, string _meat, float _price) : base(_name, _roll, _meat, _price)
        { }

        public void addChips()
        {
            Console.WriteLine("Added Chips for an extra 2,75$");
            Price += 2.75f;
        }

        public void addDrink()
        {
            Console.WriteLine("Added Drink for an extra 1,81$");
            Price += 1.81f;
        }
    }
}
