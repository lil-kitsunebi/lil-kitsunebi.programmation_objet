﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shamim___Potvin__ML
{
    class burger
    {
        public string Name { get; set; }
        public string Roll { get; set; }
        public string Meat { get; set; }
        public float Price { get; set; }

        public burger (string _name, string _roll, string _meat, float _price)
        {
            Name = _name;
            Roll = _roll;
            Meat = _meat;
            Price = _price;
        }

        public void Display()
        {
            Console.WriteLine("\n" + Name + " hamburger on a " + Roll + " roll with " + Meat + ", price is " + Price + "$");
        }

        public void addTomato()
        {
            Console.WriteLine("Added Tomato for an extra 0,27$");
            Price += 0.27f;
        }

        public void addLettuce()
        {
            Console.WriteLine("Added Lettuce for an extra 0,75$");
            Price += 0.75f;
        }

        public void addCheese()
        {
            Console.WriteLine("Added Cheese for an extra 1,13$");
            Price += 1.13f;
        }

        public void addCarrot()
        {
            Console.WriteLine("Added Carrot for an extra 0,50$");
            Price += 0.5f;
        }

        public void total()
        {
            Console.WriteLine("\nTotal for this burger is " + Price + "$");
        }
    }
}
