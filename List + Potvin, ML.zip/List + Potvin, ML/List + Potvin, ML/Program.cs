﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace List___Potvin__ML
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] list = { };
            int clear = 1;
            int clearAlready = 0;
            int clearLenght = 0;
            int firstClear = 0;
            int lenghtForMSLT = 0;
            int addZero = 0;

            Console.WriteLine("P - Print numbers\nA - Add a number\nM - Display mean of the numbers\nS - Display the smallest number\nL - Display the largest number" +
                "\nN - Search for a number in the list\nC - Clearing out the list\nT - Display the sum of the numbers\nQ - Quit");
            string letter = Console.ReadLine();

            while (letter.ToLower() != "q")
            {
                if (letter.ToLower() == "p")    //print and sort numbers. Duplicates entries not allowed
                {

                    if (list.Length > 0)
                    {
                        if (clear >= 1)
                        {
                            Array.Sort(list);
                            int[] noDuplicate = list.Distinct().ToArray();

                            if (clear == 1)
                            {
                                Console.Write("\n[ ");
                                foreach (var numbers in noDuplicate)
                                { Console.Write(numbers + " "); }
                                Console.WriteLine("]");
                            }
                            else
                            {
                                if (addZero == 0)
                                {
                                    Console.Write("\n[ ");
                                    for (int i = (clearLenght - 1); i < noDuplicate.Length; i++)
                                    { Console.Write(noDuplicate[i] + " "); }
                                    Console.WriteLine("]");
                                }
                                else
                                {
                                    Console.Write("\n[ ");
                                    for (int i = clearLenght; i < noDuplicate.Length; i++)
                                    { Console.Write(noDuplicate[i] + " "); }
                                    Console.WriteLine("]");
                                }
                            }
                        }
                        else
                        { Console.WriteLine("\n[] - the list is empty"); }
                    }
                    else
                    { Console.WriteLine("\n[] - the list is empty"); }
                }

                if (letter.ToLower() == "a")    //add a number
                {
                    Console.WriteLine("\nWhat is the number you want to add? If you add a duplicate entry, the number will only appear once in the list.");
                    int addNumber = int.Parse(Console.ReadLine());

                    if (clear == 1)
                    {
                            list = list.Concat(new int[] { addNumber }).ToArray();
                            Console.WriteLine("\n" + addNumber + " added");
                    }
                    else
                    {
                        if (addNumber == 0)
                        {
                            clearLenght = 0;
                            Console.WriteLine("0 added");
                            addZero = 1;
                        }

                        else
                        {
                            list = list.Concat(new int[] { addNumber }).ToArray();
                            Console.WriteLine(addNumber + " added");
                            clear = 2;
                            clearAlready = 0;
                        }
                    }
                }

                if (letter.ToLower() == "m")    //display mean of the numbers
                {
                    if (clear >= 1)
                    {
                        if (list.Length > 0)
                        {
                            if (clear == 1)
                            {
                                int total = 0;
                                foreach (var numbers in list)
                                { total += numbers; }
                                int mean = total / list.Length;
                                Console.WriteLine("\nThe mean of the numbers is: " + mean);
                            }
                            else
                            {
                                int total = 0;
                                if (firstClear <= 1)
                                {
                                    for (int i = clearLenght; i < list.Length; i++)
                                    { total += list[i]; }
                                    int newLenght = list.Length - clearLenght;
                                    int mean = total / newLenght;
                                    Console.WriteLine("\nThe mean of the numbers is: " + mean);
                                }
                                else
                                {
                                    for (int i = lenghtForMSLT; i < list.Length; i++)
                                    { total += list[i]; }
                                    int newLenght = list.Length - lenghtForMSLT;
                                    int mean = total / newLenght;
                                    Console.WriteLine("\nThe mean of the numbers is: " + mean);
                                }
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to calculate the mean - no data"); }
                    }
                    else
                    { Console.WriteLine("\nUnable to calculate the mean - no data"); }
                }

                if (letter.ToLower() == "s")    //display the smallest number
                {
                    if (list.Length > 0)
                    {
                        if (clear >= 1)
                        {
                            if (clear == 1)
                            {
                                int smallest = list[0];
                                for (int i = 0; i < list.Length; i++)
                                {
                                    if (smallest > list[i])
                                    {
                                        int temp = smallest;
                                        smallest = list[i];
                                        list[i] = smallest;
                                    }
                                }
                                Console.WriteLine("\nThe smallest number is: " + smallest);
                            }
                            else
                            {
                                if (firstClear <= 1)
                                {
                                    int smallest = list[clearLenght];
                                    for (int i = clearLenght; i < list.Length; i++)
                                    {
                                        if (smallest > list[i])
                                        {
                                            int temp = smallest;
                                            smallest = list[i];
                                            list[i] = smallest;
                                        }
                                    }
                                    Console.WriteLine("\nThe smallest number is: " + smallest);
                                }
                                else
                                {
                                    int smallest = list[lenghtForMSLT];
                                    for (int i = lenghtForMSLT; i < list.Length; i++)
                                    {
                                        if (smallest > list[i])
                                        {
                                            int temp = smallest;
                                            smallest = list[i];
                                            list[i] = smallest;
                                        }
                                    }
                                    Console.WriteLine("\nThe smallest number is: " + smallest);
                                }
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to determine the smallest number - list is empty"); }
                    }
                    else
                    { Console.WriteLine("\nUnable to determine the smallest number - list is empty"); }
                }

                if (letter.ToLower() == "l")    //display the largest number
                {
                    if (list.Length > 0)
                    {
                        if (clear >= 1)
                        {
                            int largest = list[0];
                            if (clear == 1)
                            {
                                for (int i = 0; i < list.Length; i++)
                                {
                                    if (largest < list[i])
                                    {
                                        int temp = largest;
                                        largest = list[i];
                                        list[i] = largest;
                                    }
                                }
                                Console.WriteLine("\nThe largest number is: " + largest);
                            }
                            else
                            {
                                for (int i = lenghtForMSLT; i < list.Length; i++)
                                {
                                    if (largest < list[i])
                                    {
                                        int temp = largest;
                                        largest = list[i];
                                        list[i] = largest;
                                    }
                                }
                                Console.WriteLine("\nThe largest number is: " + largest);
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to determine the largest number - list is empty"); }
                    }
                    else
                    { Console.WriteLine("\nUnable to determine the largest number - list is empty"); }
                }

                if (letter.ToLower() == "n")    //search for a number in the list
                {
                    if (list.Length > 0)
                    {
                        if (clear >= 1)
                        {
                            Console.WriteLine("\nWhat is the number you want to search?");
                            int searchNumber = int.Parse(Console.ReadLine());
                            int count = 0;

                            if (clear == 1)
                            {
                                foreach (var numbers in list)
                                {
                                    if (numbers == searchNumber)
                                    { count += 1; }
                                }

                                if (count > 0)
                                { Console.WriteLine("\nNumber found ''" + count + "'' times in the list."); } //always going to display 1 since duplicate entries are not allowed
                                else
                                { Console.WriteLine("\nNumber not found."); }
                            }
                            else
                            {
                                for (int i = clearLenght; i < list.Length; i++)
                                {
                                    if (list[i] == searchNumber)
                                    { count += 1; }
                                }

                                if (count > 0)
                                { Console.WriteLine("\nNumber found " + count + " times in the list."); } //always display 1 since duplicate entries are not allowed
                                else
                                { Console.WriteLine("\nNumber not found."); }
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to search a number - list is empty"); }
                    }
                    else
                    { Console.WriteLine("\nUnable to search a number - list is empty"); }
                }

                if (letter.ToLower() == "c")    //clearing out the list
                {
                    if (list.Length > 0)
                    {
                        if (clearAlready == 0)
                        {
                            clear = 0;
                            clearAlready = 1;
                            addZero = 0;

                            if (firstClear == 0)
                            {
                                clearLenght = list.Length;
                                Array.Clear(list, 0, list.Length);
                                Console.WriteLine("\nClearing out the list...");
                                Console.WriteLine("[] - the list is now empty");
                                firstClear = 1;
                            }
                            else
                            {
                                lenghtForMSLT = list.Length;
                                int temp = clearLenght;
                                clearLenght = list.Length - temp;
                                
                                Array.Clear(list, 0, list.Length);
                                Console.WriteLine("\nClearing out the list...");
                                Console.WriteLine("[] - the list is now empty");
                                firstClear = 2;
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to clear the list - list is empty"); }
                        
                    }
                    else
                    { Console.WriteLine("\nUnable to clear the list - list is empty"); }
                }

                if (letter.ToLower() == "t")    //display the total
                {
                    if (list.Length > 0)
                    {
                        if (clear >= 1)
                        {
                            int total = 0;
                            if (clear == 1)
                            {
                                foreach (var numbers in list)
                                {
                                    total += numbers;
                                }
                                Console.WriteLine("\nThe sum is: " + total);
                            }
                            else
                            {
                                for (int i = clearLenght; i < list.Length; i++)
                                { total += list[i]; }
                                Console.WriteLine("\nThe sum is: " + total);
                            }
                        }
                        else
                        { Console.WriteLine("\nUnable to calculate the sum - no data"); }
                    }
                    else
                    { Console.WriteLine("\nUnable to calculate the sum - no data"); }
                }

                if (letter.ToLower() != "p" && letter.ToLower() != "a" && letter.ToLower() != "m" && letter.ToLower() != "s" && letter.ToLower() != "l" && letter.ToLower() != "n" && letter.ToLower() != "c" && letter.ToLower() != "t")
                { Console.WriteLine("\nUnknown selection, please try again"); }

                Console.WriteLine("\nP - Print numbers\nA - Add a number\nM - Display mean of the numbers\nS - Display the smallest number\nL - Display the largest number" +
                "\nN - Search for a number in the list\nC - Clearing out the list\nT - Display the sum of the numbers\nQ - Quit");
                letter = Console.ReadLine();
            }
            Console.WriteLine("\nGoodbye");
        }
    }
}
